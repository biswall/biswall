#!/bin/sh

while [ 1 ]
do
    ./bisminer
    sleep 5
done
